import math
from math import sqrt

from pymongo import MongoClient

db = MongoClient()["movielens25M"]


def getMovieTitle(movieId):
    movies = db.movies
    title = ""
    for movie in movies.find({'movieId': movieId}):
        title = movie['title']
    return title


def getUserRatingso(db, userId):
    ratings = db.ratings
    rating_dic = {}
    sub_rating = {}

    # get_rating_docs = ratings.find({'userId': 1193}).count()
    for rating in ratings.find({'userId': userId}):

        # for rating in ratings.find():
        if rating['userId'] in rating_dic:
            sub_rating = rating_dic[rating['userId']]
            if rating['movieId'] in sub_rating:
                pass
                # print("It is already in the diccionary : " , rating['movieid']," ", rating['rating'] )
            else:
                sub_rating[rating['movieId']] = rating['rating']
                rating_dic[rating['userId']] = sub_rating
                # print(getMovieTitle(rating['movieId']))

                # print("1=>")
        else:
            sub_rating[rating['movieId']] = rating['rating']
            rating_dic[rating['userId']] = sub_rating
            # print(getMovieTitle(rating['movieId']))
            # print("2=>")

    # print(rating_dic)
    # rating_dic = sorted(rating_dic, key=lambda k: k['userid'])
    return rating_dic


def getUserRatings(db, userId):
    global rating
    ratings = db.ratings
    # result = ratings.aggregate([ {'$match' : {'userId' : userId}}, { '$group' : { '_id' : "$userId", 'rating': { '$push': { 'movieId': "$movieId", 'rating': "$rating" } } } }])
    result = ratings.aggregate([{'$match': {'userId': userId}}, {'$group': {'_id': "$userId", 'rating': {'$addToSet': {'movieId': "$movieId", 'rating': "$rating"}}}}])
    for r in result:
        rating = r['rating']

    resultado = {}
    for element  in rating:
            resultado[element['movieId']]= element['rating']
    return resultado


def getAllUsers(db):
    ratings = db.ratings
    users = ratings.distinct("userId")
    return users


class recommender:

    def __init__(self, k=1, metric='pearson', n=5):
        """ initialize recommender
        currently, if data is dictionary the recommender is initialized
        to it.
        For all other data types of data, no initialization occurs
        k is the k value for k nearest neighbor
        metric is which distance formula to use
        n is the maximum number of recommendations to make"""
        self.k = k
        self.n = n
        self.username2id = {}
        self.userid2name = {}
        self.productid2name = {}
        # Name of the metric
        self.metric = metric
        if self.metric == 'pearson':
            self.fn = self.pearson
        elif self.metric == 'manhattan':
            self.fn = self.manhattan
        elif self.metric == 'euclidiana':
            self.fn = self.euclidiana
        elif self.metric == 'coseno':
            self.fn = self.coseno
        else:
            self.fn = self.pearson
        # The following two variables are used for Slope One
        #
        self.frequencies = {}
        self.deviations = {}



    def convertProductID2name(self, id):
        """Given product id number return product name"""
        if id in self.productid2name:
            return self.productid2name[id]
        else:
            return id

    def pearson(self, rating1, rating2):
        sum_xy = 0
        sum_x = 0
        sum_y = 0
        sum_x2 = 0
        sum_y2 = 0
        n = 0
        for key in rating1:
            if key in rating2:
                n += 1
                x = rating1[key]
                y = rating2[key]
                sum_xy += x * y
                sum_x += x
                sum_y += y
                sum_x2 += pow(x, 2)
                sum_y2 += pow(y, 2)
        if n == 0:
            return 0
        # now compute denominator
        denominator = (sqrt(sum_x2 - pow(sum_x, 2) / n)
                       * sqrt(sum_y2 - pow(sum_y, 2) / n))
        if denominator == 0:
            return 0
        else:
            return (sum_xy - (sum_x * sum_y) / n) / denominator

    def manhattan(self, rating1, rating2):
        """Computes the Manhattan distance. Both rating1 and rating2 are dictionaries
           of the form {'The Strokes': 3.0, 'Slightly Stoopid': 2.5}"""
        distance = 0
        commonRatings = False
        for key in rating1:
            if key in rating2:
                distance += abs(rating1[key] - rating2[key])
                commonRatings = True
        if commonRatings:
            return distance
        else:
            return -1  # Indicates no ratings in common

    def euclidiana(self, rating1, rating2):
        """Computes the Euclidean distance. Both rating1 and rating2 are dictionaries
           of the form {'The Strokes': 3.0, 'Slightly Stoopid': 2.5}"""
        distance = 0
        commonRatings = False
        for key in rating1:
            if key in rating2:
                distance += math.pow(rating1[key] - rating2[key], 2)
                commonRatings = True
        if commonRatings:
            return math.sqrt(distance)
        else:
            return -1  # Indicates no ratings in common

    def coseno(self, rating1, rating2):
        sum_xy = 0
        sum_x = 0
        sum_y = 0
        sum_x2 = 0
        sum_y2 = 0
        n = 0
        for key in rating1:
            if key in rating2:
                n += 1
                x = rating1[key]
                y = rating2[key]
                sum_xy += x * y
                sum_x += x
                sum_y += y
                sum_x2 += pow(x, 2)
                sum_y2 += pow(y, 2)
        sqr_sum_x2 = math.sqrt(sum_x2)
        sqr_sum_y2 = math.sqrt(sum_y2)
        # now compute denominator
        denominator = (sqr_sum_x2 * sqr_sum_y2)
        if denominator == 0:
            return 0
        else:
            return sum_xy / denominator


    def computeNearestNeighbor(self, userid):
        """creates a sorted list of users based on their distance to
        username"""
        distances = []
        print("\n----------Distance type", self.metric, '----------------------------------------')

        users = getAllUsers(db)
        userRatings = getUserRatings(db, userid)
        i = 0

        for instance in users:
            print("Numero de usuarios" , len(users),"i ", i)
            if instance != userid:
                rating1 = userRatings
                rating2 = getUserRatings(db, instance)
                distance = self.fn(rating1, rating2)
                distances.append((instance, distance))
                # print(userid, "-", instance, ":", distance)
            i=i+1
        # sort based on distance -- closest first
        distances.sort(key=lambda artistTuple: artistTuple[1],
                       reverse=True)

        return distances

    def recommend(self, user):
        """Give list of recommendations"""
        recommendations = {}
        # first get list of users  ordered by nearness
        nearest = self.computeNearestNeighbor(user)
        # print("Vecinos cercanos:", nearest)
        #
        # now get the ratings for the user
        #
        # userRatings = self.data[user]
        userRatings = getUserRatings(db, user)

        # print("User Ratings:", userRatings)
        #
        # determine the total distance
        totalDistance = 0.0
        for i in range(self.k):
            totalDistance += nearest[i][1]
        # print("Distance:", totalDistance)
        # now iterate through the k nearest neighbors
        # accumulating their ratings
        # print("\n++++++++++++++Starting Recomendations++++++++++++++++")
        for i in range(self.k):
            # compute slice of pie
            weight = nearest[i][1] / totalDistance
            # print("Weight:", weight)
            # get the name of the person
            name = nearest[i][0]
            # print("\nNeighbor:", name)
            # get the ratings for this person
            neighborRatings = getUserRatings(db, name)
            # print("User ratings:", userRatings)
            # print("Neighbor ratings:", neighborRatings)
            # get the name of the person
            # now find bands neighbor rated that user didn't
            for artist in neighborRatings:
                # print("artist:", artist)
                if not artist in userRatings:
                    if artist not in recommendations:
                        recommendations[artist] = (neighborRatings[artist]
                                                   * weight)
                        # print("Recomendacion", artist, "-", recommendations[artist])
                    else:
                        recommendations[artist] = (recommendations[artist]
                                                   + neighborRatings[artist]
                                                   * weight)
                        # print("Recomendacion", artist, "-", recommendations[artist])
                else:
                    pass  # print(" No Recomendacion")

        # now make list from dictionary
        recommendations = list(recommendations.items())
        recommendations = [(self.convertProductID2name(k), v)
                           for (k, v) in recommendations]
        # finally sort and return
        recommendations.sort(key=lambda artistTuple: artistTuple[1],
                             reverse=True)
        # Return the first n items
        print("\n-> Recomendaciones Finales 2=", recommendations[:self.n], "para:", user)

        return recommendations[:self.n]


def main():
    userId = 1194
    recomendacion1 = recommender(5, 'euclidiana', 5)
    recomendacion1.recommend(userId)

    print("Finish")


if __name__ == '__main__':
    main()
