from pymongo import MongoClient
db = MongoClient()["movielens25M"]

def getUserRatings(userId):
    global rating
    ratings = db.ratings
    result = ratings.aggregate([{'$match': {'userId': userId}}, {'$group': {'_id': "$userId", 'rating': {'$addToSet': {'movieId': "$movieId", 'rating': "$rating"}}}}])
    for r in result:
        rating = r['rating']

    resultado = {}
    for element  in rating:
            resultado[element['movieId']]= element['rating']
    return resultado


def getAllUsers(db):
    ratings = db.ratings
    users = ratings.distinct("userId")
    return users

def main():
    users = getAllUsers(db)
    resultado = {}
    for instance in users:
        result = getUserRatings(instance)
        resultado[instance] =result
    print("Finish")


if __name__ == '__main__':
    main()
