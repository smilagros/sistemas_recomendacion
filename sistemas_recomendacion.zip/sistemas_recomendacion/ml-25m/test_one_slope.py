# coding=utf-8
import codecs

from pymongo import MongoClient

db = MongoClient()["movielens25M"]

myScore = {'Snakes on a Plane': 3.0, 'Forest Gump': 5.0, 'Jaws': 1.0, 'Napolean Dynamite': 3.0, 'Toy Story': 4.0}


def getUserRatings(userId):
    global rating
    ratings = db.ratings
    result = ratings.aggregate([{'$match': {'userId': userId}}, {
        '$group': {'_id': "$userId", 'rating': {'$addToSet': {'movieId': "$movieId", 'rating': "$rating"}}}}])
    for r in result:
        rating = r['rating']

    resultado = {}
    for element in rating:
        resultado[element['movieId']] = element['rating']
    return resultado


def getAllUsers(db):
    ratings = db.ratings
    users = ratings.distinct("userId")
    return users


def getData():
    users = getAllUsers(db)
    resultado = {}
    for instance in users:
        result = getUserRatings(instance)
        resultado[instance] = result
    return resultado


class Recommender:
    def __init__(self, data):
        self.data = data
        self.frequencies = {}
        self.deviations = {}

    # Calcular la desviación
    def computeDeviations(self):
        db['deviations'].remove({});
        deviations = db['deviations']
        # Recorre la información de puntuación de cada usuario
        for ratings in self.data.values():
            # print ratings
            for (item, rating) in ratings.items():
                # Agregue elementos a las desviaciones de frecuencias del diccionario
                # Si no hay un nombre de banda, agregue frecuencias = {nombre de banda: {}} a las frecuencias, de manera similar, desviaciones = {nombre de banda: {}}
                self.frequencies.setdefault(item, {})
                self.deviations.setdefault(item, {})
                # print self.frequencies
                # print self.deviations
                #
                for (item2, rating2) in ratings.items():
                    if item != item2:
                        # Si las frecuencias [nombre de la banda] = {}, configure las frecuencias [nombre de la banda] = {nombre de la banda 2: 0}
                        # De manera similar, desviaciones [nombre de la banda] = {nombre de la banda 2: 0.0}
                        self.frequencies[item].setdefault(item2, 0)
                        # print self.frequencies
                        self.deviations[item].setdefault(item2, 0.0)
                        # print self.deviations
                        # Si las frecuencias [nombre de la banda]! = {}, es decir, al recorrer sucesivamente los nombres de las bandas, se acumula el valor de item2
                        self.frequencies[item][item2] += 1
                        # print self.frequencies
                        self.deviations[item][item2] += rating - rating2

                        frecuency = self.frequencies[item][item2]
                        desviation = self.deviations[item][item2]
                        # a document
                        deviationFind = deviations.find_one({'$and': [{"item": item}, {"item2": item2}]})
                        if deviationFind != None:
                            deviations.find_one_and_update({'$and': [{"item": item}, {"item2": item2}]},
                                                           {'$set': {"frecuency": frecuency, "desviation": desviation}})
                        else:
                            deviations.insert_one(
                                {"item": item, "item2": item2, "frecuency": frecuency, "desviation": desviation})

            # print(self.deviations)

    def computeDeviationsUpdate(self):

        global deviation
        deviations = db.deviations
        result = deviations.aggregate([{
            '$group': {'_id': "$item", 'desviation': {'$addToSet': {'item2': "$item2", 'desviation': "$desviation"}}}}])

        deviationsDiccionary = {}

        for r in result:
            deviationsDiccionary[r['_id']] = r['desviation']
        # Recorre el diccionario de desviaciones, desviations = {item: {item2: sum of desviations}},
        # frecuencias = {elemento: {elemento2: número de usuarios que puntúan el elemento elemento2 juntos}}
        for (item, ratings) in deviationsDiccionary.items():
            for item2 in ratings:
                # Reemplace, la suma de las desviaciones, con, la desviación después de dividir por el número de usuarios que puntuaron juntos,
                # deviations.find_one_and_update({'$and': [{"item": item}, {"item2": item2}]},  {'$set': {"frecuency": frecuency, "desviation": desviation}})
                ratings[item2] /= self.frequencies[item][item2]
                deviations.find_one_and_update({'$and': [{"item": item}, {"item2": item2}]},
                                               {'$set': {"desviation": ratings[item2]}})

    def slopeOneRecommendations(self, userRatings):
        recommendations = {}
        frequencies = {}
        # Recorre cada elemento en userRatings, userRatings son todas las bandas que el usuario ha calificado
        for (userItem, userRating) in userRatings.items():
            # Atraviesa cada elemento en desviaciones
            for (diffItem, diffRatings) in self.deviations.items():
                # Si el usuario no ha puntuado esta banda (diffItem) y hay una desviación entre diffItem y userItem, se puede recomendar diffItem al usuario
                if diffItem not in userRatings and userItem in self.deviations[diffItem]:
                    # freq almacena el número de usuarios que puntuaron juntos diffItem userItem
                    freq = self.frequencies[diffItem][userItem]
                    # recommendations = {diffItem: 0.0}  frequencies = {diffItem: 0}
                    recommendations.setdefault(diffItem, 0.0)
                    frequencies.setdefault(diffItem, 0)
                    # recomendaciones [diffItem] = frecuencia del numerador [diffItem] = denominador
                    recommendations[diffItem] += (diffRatings[userItem] + userRating) * freq
                    frequencies[diffItem] += freq
        # Calcular la puntuación final
        for (item, value) in recommendations.items():
            recommendations[item] = value / frequencies[item]
            # print recommendations

        return sorted(recommendations.items(), key=lambda d: d[1], reverse=True)


#
# r = Recommender(users)
# userRating = users['Ben']
# recommend = r.slopeOneRecommendations(userRating)

my = Recommender(getData())
# print(my.computeDeviations())
#my.computeDeviationsUpdate()
myRecommend = my.slopeOneRecommendations(myScore)
print(myRecommend)

# Video de recomendación final[('Star Wars', 4.494623655913978), ('Shawshank Redemption', 4.42),
#  ('The Dark Knight', 4.375), ('The Matrix', 4.021505376344086), ('Gladiator', 3.8701298701298703)]
